# WSM-project
## 界面介绍
mainpage.py 主界面

resultpage1.py : ranked search界面

resultpage2.py : boolean search界面

FullText_page.py : 完整文本展示界面

Table.py : ranked search界面和boolean search界面中的表格模块

RankedSearch.py : RankedSearch算法

action.py : 程序入口，集成了所有窗口

QA_S/summarize_QA.py summarize和QA算法，需要有模型文件才能用，模型文件在群里

## 使用
直接运行action.py打开界面即可
