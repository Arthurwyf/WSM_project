## 这个目录下放三个文件，可参考test_env目录下的那三个（只包含10000条新闻）
## 文件地址：
文件大小: 4.6 GB

分享内容: dict_post_fq.zip 

链接地址:https://jbox.sjtu.edu.cn/l/01amJe  

 来自于: 陈子啸  
 ## RankedsSearch.py  中的第23行 root = 'full_env/' 修改访问的文件目录
